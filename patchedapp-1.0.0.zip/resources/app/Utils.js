'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _discord_utils = require('discord_utils');

var _discord_utils2 = _interopRequireDefault(_discord_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _discord_utils2.default;
module.exports = exports['default'];
