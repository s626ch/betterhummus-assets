'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _electron = require('electron');

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _AutoRun = require('./AutoRun');

var _AutoRun2 = _interopRequireDefault(_AutoRun);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function exposeAsarTempFile(asarPath, fileName) {
  var fullPathToAsarFile = _path2.default.join(_electron.app.getAppPath(), asarPath, fileName);
  var data = _fs2.default.readFileSync(fullPathToAsarFile);
  var nativeFilePath = _path2.default.join(_electron.app.getPath('userData'), fileName);
  _fs2.default.writeFileSync(nativeFilePath, data);
  return nativeFilePath;
}

var badgeEnabledImagePath = null;
var badgeDisableImagePath = null;
if (process.platform === 'win32') {
  badgeDisableImagePath = exposeAsarTempFile('images', 'tray.png');
  badgeEnabledImagePath = exposeAsarTempFile('images', 'tray-unread.png');
} else if (process.platform === 'linux') {
  badgeDisableImagePath = exposeAsarTempFile('images', 'linux-tray.png');
  badgeEnabledImagePath = exposeAsarTempFile('images', 'linux-tray-unread.png');
}

var SystemTray = function () {
  function SystemTray(onCheckForUpdates, onQuit, onTrayClicked, appSettings) {
    var _this = this;

    _classCallCheck(this, SystemTray);

    var myName = _path2.default.basename(process.execPath, '.exe');

    this.appSettings = appSettings;
    this.atomTray = new _electron.Tray(badgeDisableImagePath);
    this.atomTray.setToolTip(myName);

    this.contextMenu = [];

    if (process.platform === 'linux') {
      this.contextMenu = this.contextMenu.concat([{
        label: 'Open ' + myName,
        type: 'normal',
        click: onTrayClicked
      }]);
    }

    var autoRunIndex = this.contextMenu.length;
    this.contextMenu = this.contextMenu.concat([{
      label: 'Run ' + myName + ' when my computer starts',
      type: 'checkbox',
      checked: false,
      enabled: false,
      click: this.toggleRunOnStartup.bind(this)
    }, {
      label: 'Check for updates',
      type: 'normal',
      click: onCheckForUpdates
    }, {
      type: 'separator'
    }, {
      label: 'Quit ' + myName,
      type: 'normal',
      click: onQuit
    }]);

    this.atomTray.setContextMenu(_electron.Menu.buildFromTemplate(this.contextMenu));

    _AutoRun2.default.isAutoRunning(function (isAutoRunning) {
      _this.contextMenu[autoRunIndex].checked = isAutoRunning;
      _this.contextMenu[autoRunIndex].enabled = true;
      _this.atomTray.setContextMenu(_electron.Menu.buildFromTemplate(_this.contextMenu));
    });

    _electron.ipcMain.on('BADGE_IS_ENABLED', function () {
      _this.setBadge(true);
    });

    _electron.ipcMain.on('BADGE_IS_DISABLED', function () {
      _this.setBadge(false);
    });

    _electron.ipcMain.on('SET_ICON', function (_event, _ref) {
      var icon = _ref.icon;

      _this.setIcon(icon);
    });

    this.atomTray.on('click', onTrayClicked);
  }

  _createClass(SystemTray, [{
    key: 'toggleRunOnStartup',
    value: function toggleRunOnStartup(menuItem) {
      if (!menuItem.checked) {
        _AutoRun2.default.clear(function () {});
      } else {
        _AutoRun2.default.install(function () {});
      }
    }
  }, {
    key: 'setBadge',
    value: function setBadge(enabled) {
      this.atomTray.setImage(enabled ? badgeEnabledImagePath : badgeDisableImagePath);
    }
  }, {
    key: 'setIcon',
    value: function setIcon(_icon) {
      // Disabling for now due to the volume mixer bug
      // https://trello.com/c/wER4jCZN/283-giant-discord-in-sound-panel
      // const win = BrowserWindow.fromId(global.mainWindowId);
      // const img = nativeImage.createFromDataURL(icon);
      // win.setIcon(img);
    }
  }, {
    key: 'setOverlayIcon',
    value: function setOverlayIcon(description, iconDataURL) {
      var win = _electron.BrowserWindow.fromId(global.mainWindowId);
      if (!iconDataURL) {
        win.setOverlayIcon(null, description);
        return;
      }

      var img = _electron.nativeImage.createFromDataURL(iconDataURL);
      win.setOverlayIcon(img, description);
    }
  }, {
    key: 'displayHowToCloseHint',
    value: function displayHowToCloseHint() {
      if (!this.appSettings.get('trayBalloonShown')) {
        // todo: localize
        var balloonMessage = 'Hi! hummus will run in the background to keep you in touch with your friends.' + '\n\nYou can right-click here to quit.';
        this.appSettings.set('trayBalloonShown', true);
        this.appSettings.save();
        this.atomTray.displayBalloon({
          title: 'hummus',
          content: balloonMessage
        });
      }
    }
  }]);

  return SystemTray;
}();

exports.default = SystemTray;
module.exports = exports['default'];
