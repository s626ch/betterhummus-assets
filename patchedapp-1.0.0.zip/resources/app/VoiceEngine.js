'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _discord_voice = require('discord_voice');

var _discord_voice2 = _interopRequireDefault(_discord_voice);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _discord_voice2.default;
module.exports = exports['default'];
